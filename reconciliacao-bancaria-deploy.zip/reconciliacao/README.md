# Reconciliação Bancária

Webapp para reconciliação de cheques entre a contabilidade e os extratos bancários da CGD, Novo Banco e BCP.

---

## Estrutura do projeto

```
reconciliacao/
├── public/
│   └── index.html        ← a webapp completa
├── .github/
│   └── workflows/
│       └── deploy.yml    ← deploy automático via GitHub Actions
├── firebase.json         ← configuração do Firebase Hosting
├── .firebaserc           ← ID do projeto Firebase
└── .gitignore
```

---

## 1. Publicar no GitHub

```bash
# Na pasta do projeto
git init
git add .
git commit -m "primeira versão"

# Liga ao teu repositório GitHub (cria um repo novo em github.com primeiro)
git remote add origin https://github.com/SEU-UTILIZADOR/SEU-REPO.git
git branch -M main
git push -u origin main
```

---

## 2. Deploy manual no Firebase (primeira vez)

### Instalar o Firebase CLI (se ainda não tiveres)
```bash
npm install -g firebase-tools
```

### Login e deploy
```bash
firebase login
firebase use SEU-PROJETO-FIREBASE-ID
firebase deploy
```

A webapp fica disponível em `https://SEU-PROJETO-FIREBASE-ID.web.app`

---

## 3. Deploy automático via GitHub Actions (opcional)

A cada `git push` para `main`, o deploy é feito automaticamente.

### Configuração (uma vez só)

1. No terminal, corre:
   ```bash
   firebase init hosting:github
   ```
   Segue as instruções — vai criar automaticamente o secret no GitHub.

2. Ou manualmente:
   - Vai a **Firebase Console → Project Settings → Service Accounts**
   - Gera uma nova chave privada (ficheiro JSON)
   - No GitHub, vai a **Settings → Secrets → Actions**
   - Cria um secret chamado `FIREBASE_SERVICE_ACCOUNT` e cola o conteúdo do JSON

3. Edita `.firebaserc` e `.github/workflows/deploy.yml` com o teu **Project ID** real.

### Fazer deploy depois de alterações
```bash
git add .
git commit -m "descrição da alteração"
git push
```
O GitHub Actions trata do resto automaticamente.

---

## Como usar a webapp

1. Exporta o extrato da contabilidade (Excel/CSV) com colunas: Data, Descrição (ex: `CHEQUE 164709411`), Valor, Banco
2. Exporta os extratos bancários de cada banco (CGD, Novo Banco, BCP)
3. Carrega os ficheiros na app e clica **Reconciliar**
